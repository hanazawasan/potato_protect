#ifndef VICTORY_H
#define VICTORY_H
#include<QMainWindow>
#include "config.h"
#include<QPaintEvent>
#include<QPainter>

class Victory : public QMainWindow
{
    Q_OBJECT
public:
    explicit Victory(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *event);

signals:

};

#endif // VICTORY_H
