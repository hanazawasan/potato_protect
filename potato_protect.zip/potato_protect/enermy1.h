#ifndef ENERMY1_H
#define ENERMY1_H
#include "enermy.h"
#include "config.h"
class Enermy1:public Enermy
{
public:
    Enermy1();

};

#endif // ENERMY1_H
