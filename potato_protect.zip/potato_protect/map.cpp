#include "map.h"

Map::Map()
{
    m_map.load(":/pics/qing.png");
}
