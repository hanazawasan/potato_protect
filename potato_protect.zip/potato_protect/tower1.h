#ifndef TOWER1_H
#define TOWER1_H

#include "tower.h"
#include "bullet1.h"


class Tower1:Tower
{
public:
    Tower1();
    void shoot1();
     Bullet1 m_bullets[BULLET_NUM];
};

#endif // TOWER1_H
