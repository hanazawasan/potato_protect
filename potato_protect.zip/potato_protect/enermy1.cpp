#include "enermy1.h"

Enermy1::Enermy1()
{
    m_enermy.load(":/pics/enermy1.png");
    m_speed=ENERMY1_SPEED;
    m_blood=ENERMY1_BLOOD;
}


