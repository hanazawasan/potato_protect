#ifndef ENERMYBULLET_H
#define ENERMYBULLET_H
#include "bullet.h"

class EnermyBullet:public Bullet
{
public:
    EnermyBullet();
    void updatePosition();
};

#endif // ENERMYBULLET_H
