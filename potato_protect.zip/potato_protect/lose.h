#ifndef LOSE_H
#define LOSE_H


#include<QMainWindow>
#include "config.h"
#include<QPaintEvent>
#include<QPainter>

class Lose : public QMainWindow
{
    Q_OBJECT
public:
    explicit Lose(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *event);

signals:

};

#endif // LOSE_H
