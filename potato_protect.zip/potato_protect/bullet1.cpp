#include "bullet1.h"

Bullet1::Bullet1()
{
    m_Bullet.load(":/pics/bullet1.png");

}
