#ifndef BULLET1_H
#define BULLET1_H

#include "bullet.h"

class Bullet1:Bullet
{
public:
    Bullet1();
};

#endif // BULLET1_H
